<?php phphinfo(); ?>
