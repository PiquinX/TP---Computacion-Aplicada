#!/bin/bash
# Script: backup_full.sh
# Uso: ./backup_full.sh origen destino
# Ejemplo: ./backup_full.sh /var/log /backup_dir
# Opción de ayuda: ./backup_full.sh -help

# Función de ayuda
if [[ "$1" == "-help" ]]; then
    echo "Uso: $0 origen destino"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "Genera un archivo comprimido con la fecha actual (YYYYMMDD)"
    exit 0
fi

# Validación de argumentos (debe haber 2 si o si)
if [[ $# -ne 2 ]]; then
    echo "Error: Se deben especificar ORIGEN y DESTINO"
    echo "Use -help para más información"
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Validar existencia de los directorios
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio de origen $ORIGEN no existe"
    exit 2
fi

if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El directorio de destino $DESTINO no existe"
    exit 3
fi


# Crear nombre de backup
FECHA=$(date +%Y%m%d)
# basename devuelve el ultimo componente de un path.
NOMBRE=$(basename "$ORIGEN")_bkp_$FECHA.tar.gz
ARCHIVO="$DESTINO/$NOMBRE"

# Ejecutar backup
tar -czf "$ARCHIVO" "$ORIGEN" 2> /dev/null

# verificar el valor de ejecucion del comando anterior (0 = exitoso)
if [[ $? -eq 0 ]]; then
    echo "Backup completado: $ARCHIVO"
else
    echo "Error al generar el backup"
    exit 4
fi
